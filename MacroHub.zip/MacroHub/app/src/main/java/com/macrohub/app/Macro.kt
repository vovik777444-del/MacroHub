package com.macrohub.app

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

enum class T(val title: String, val fields: List<String>) {
    TORCH("Фонарик", listOf("on / off / toggle")),
    DND("Не беспокоить", listOf("on / off")),
    VOLUME("Громкость медиа", listOf("0–100 %")),
    MEDIA("Пауза / плей", listOf()),
    SMS("SMS", listOf("Номер", "Текст")),
    CALL("Звонок", listOf("Номер")),
    APP("Открыть приложение", listOf("Пакет (com.android.chrome)")),
    URL("Открыть ссылку", listOf("https://...")),
    HTTP("HTTP-запрос", listOf("URL", "GET или POST", "Тело запроса")),
    TIMER("Таймер", listOf("Секунды")),
    ALARM("Будильник", listOf("Час", "Минуты")),
    DELAY("Пауза", listOf("Миллисекунды")),
    TOAST("Сообщение", listOf("Текст"))
}

data class Action(val type: T, val args: List<String> = List(type.fields.size) { "" })
data class Macro(val id: Long, val name: String, val color: Int, val actions: List<Action>)

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("macros", Context.MODE_PRIVATE)

    fun load(c: Context): List<Macro> {
        val s = prefs(c).getString("data", null) ?: return listOf(
            Macro(1, "Фонарик", 0, listOf(Action(T.TORCH, listOf("toggle")))),
            Macro(2, "Тишина", 1, listOf(Action(T.DND, listOf("on")), Action(T.VOLUME, listOf("0"))))
        )
        val arr = JSONArray(s)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val acts = o.getJSONArray("actions")
            Macro(o.getLong("id"), o.getString("name"), o.getInt("color"),
                (0 until acts.length()).map { j ->
                    val x = acts.getJSONObject(j); val a = x.getJSONArray("a")
                    Action(T.valueOf(x.getString("t")), (0 until a.length()).map { a.getString(it) })
                })
        }
    }

    fun save(c: Context, list: List<Macro>) {
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(JSONObject().put("id", m.id).put("name", m.name).put("color", m.color)
                .put("actions", JSONArray(m.actions.map {
                    JSONObject().put("t", it.type.name).put("a", JSONArray(it.args))
                })))
        }
        prefs(c).edit().putString("data", arr.toString()).apply()
    }
}

object Runner {
    private var torch = false

    suspend fun run(c: Context, m: Macro) {
        for (a in m.actions) {
            try { exec(c, a) } catch (e: Exception) { toast(c, "${a.type.title}: ${e.message}") }
        }
    }

    private fun toast(c: Context, t: String) =
        Handler(Looper.getMainLooper()).post { Toast.makeText(c, t, Toast.LENGTH_LONG).show() }

    private fun go(c: Context, i: Intent) = c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    private suspend fun exec(c: Context, a: Action) {
        fun s(i: Int) = a.args.getOrElse(i) { "" }.trim()
        when (a.type) {
            T.TORCH -> {
                val cm = c.getSystemService(CameraManager::class.java)
                torch = when (s(0).lowercase()) { "on" -> true; "off" -> false; else -> !torch }
                cm.setTorchMode(cm.cameraIdList.first(), torch)
            }
            T.DND -> {
                val nm = c.getSystemService(NotificationManager::class.java)
                if (nm.isNotificationPolicyAccessGranted) {
                    nm.setInterruptionFilter(
                        if (s(0).lowercase() == "on") NotificationManager.INTERRUPTION_FILTER_NONE
                        else NotificationManager.INTERRUPTION_FILTER_ALL)
                } else {
                    toast(c, "Разрешите доступ к «Не беспокоить»")
                    go(c, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                }
            }
            T.VOLUME -> {
                val am = c.getSystemService(AudioManager::class.java)
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, max * s(0).toInt().coerceIn(0, 100) / 100, 0)
            }
            T.MEDIA -> {
                val am = c.getSystemService(AudioManager::class.java)
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
            }
            T.SMS -> {
                @Suppress("DEPRECATION")
                val sm = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
                sm.sendTextMessage(s(0), null, a.args.getOrElse(1) { "" }, null, null)
                toast(c, "SMS отправлено")
            }
            T.CALL -> go(c, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + s(0))))
            T.APP -> go(c, c.packageManager.getLaunchIntentForPackage(s(0)) ?: error("приложение не найдено"))
            T.URL -> go(c, Intent(Intent.ACTION_VIEW, Uri.parse(s(0))))
            T.HTTP -> withContext(Dispatchers.IO) {
                val con = URL(s(0)).openConnection() as HttpURLConnection
                con.connectTimeout = 8000; con.readTimeout = 8000
                con.requestMethod = if (s(1).uppercase() == "POST") "POST" else "GET"
                if (con.requestMethod == "POST") {
                    con.doOutput = true
                    con.setRequestProperty("Content-Type", "application/json")
                    con.outputStream.use { it.write(a.args.getOrElse(2) { "" }.toByteArray()) }
                }
                toast(c, "HTTP ${con.responseCode}")
                con.disconnect()
            }
            T.TIMER -> go(c, Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, s(0).toInt()).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            T.ALARM -> go(c, Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, s(0).toInt()).putExtra(AlarmClock.EXTRA_MINUTES, s(1).toInt())
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            T.DELAY -> delay(s(0).toLongOrNull() ?: 1000)
            T.TOAST -> toast(c, s(0))
        }
    }
}
