package com.macrohub.app

import android.Manifest
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

val Gradients = listOf(
    Color(0xFF7C4DFF) to Color(0xFF448AFF), Color(0xFFFF6E40) to Color(0xFFFF4081),
    Color(0xFF00C9A7) to Color(0xFF2979FF), Color(0xFFFFB300) to Color(0xFFFF6D00),
    Color(0xFF8E24AA) to Color(0xFFEC407A), Color(0xFF43A047) to Color(0xFF00BFA5)
)
private val Bg = Color(0xFF0F1115); private val Card = Color(0xFF1B1E26)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF8C7CFF), background = Bg, surface = Card)) {
                Surface(Modifier.fillMaxSize(), color = Bg) { App() }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var macros by remember { mutableStateOf(Store.load(ctx)) }
    var editing by remember { mutableStateOf<Macro?>(null) }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LaunchedEffect(Unit) {
        perms.launch(arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.CALL_PHONE, Manifest.permission.POST_NOTIFICATIONS))
    }
    fun commit(l: List<Macro>) { macros = l; Store.save(ctx, l) }

    editing?.let { m ->
        Editor(m, onSave = { n -> commit(if (macros.any { it.id == n.id }) macros.map { if (it.id == n.id) n else it } else macros + n); editing = null },
            onDelete = { commit(macros.filter { it.id != m.id }); editing = null },
            onClose = { editing = null })
        return
    }

    Box(Modifier.fillMaxSize().statusBarsPadding()) {
        Column(Modifier.padding(20.dp)) {
            Text("Макросы", fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("Нажмите — выполнить. Удерживайте — изменить.", color = Color.Gray, modifier = Modifier.padding(bottom = 16.dp))
            LazyVerticalGrid(GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(macros, key = { it.id }) { m ->
                    val g = Gradients[m.color % Gradients.size]
                    Box(Modifier.height(120.dp).clip(RoundedCornerShape(24.dp))
                        .background(Brush.linearGradient(listOf(g.first, g.second)))
                        .combinedClickable(onClick = { scope.launch(Dispatchers.Default) { Runner.run(ctx.applicationContext, m) } },
                            onLongClick = { editing = m })
                        .padding(16.dp)) {
                        Text(m.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.align(Alignment.TopStart))
                        Text("${m.actions.size} дейст.", color = Color.White.copy(alpha = .8f), modifier = Modifier.align(Alignment.BottomStart))
                    }
                }
            }
        }
        ExtendedFloatingActionButton(onClick = { editing = Macro(System.currentTimeMillis(), "", macros.size % Gradients.size, emptyList()) },
            modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(20.dp)) { Text("+ Новый макрос") }
    }
}

@Composable
fun Editor(start: Macro, onSave: (Macro) -> Unit, onDelete: () -> Unit, onClose: () -> Unit) {
    var name by remember { mutableStateOf(start.name) }
    var color by remember { mutableIntStateOf(start.color) }
    val acts = remember { mutableStateListOf<Action>().apply { addAll(start.actions) } }
    var menu by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Редактор", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(name, { name = it }, label = { Text("Название") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Gradients.forEachIndexed { i, g ->
                Box(Modifier.size(if (i == color) 40.dp else 32.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(g.first, g.second)))
                    .combinedClickableSimple { color = i })
            }
        }
        acts.forEachIndexed { idx, a ->
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${idx + 1}. ${a.type.title}", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    TextButton({ acts.removeAt(idx) }) { Text("Удалить") }
                }
                a.type.fields.forEachIndexed { fi, label ->
                    OutlinedTextField(a.args.getOrElse(fi) { "" }, { v ->
                        acts[idx] = a.copy(args = a.args.toMutableList().also { while (it.size <= fi) it.add("") ; it[fi] = v })
                    }, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                }
            }
        }
        Box {
            OutlinedButton({ menu = true }, Modifier.fillMaxWidth()) { Text("+ Добавить действие") }
            DropdownMenu(menu, { menu = false }) {
                T.entries.forEach { t -> DropdownMenuItem(text = { Text(t.title) }, onClick = { acts.add(Action(t)); menu = false }) }
            }
        }
        Button({ onSave(Macro(start.id, name.ifBlank { "Макрос" }, color, acts.toList())) }, Modifier.fillMaxWidth()) { Text("Сохранить") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClose) { Text("Отмена") }
            TextButton(onDelete) { Text("Удалить макрос", color = Color(0xFFFF6B6B)) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
fun Modifier.combinedClickableSimple(onClick: () -> Unit) = this.combinedClickable(onClick = onClick)
